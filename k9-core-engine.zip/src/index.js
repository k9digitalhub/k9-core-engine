export default {
  async fetch(request, env) { return new Response('K9 Engine'); }
}